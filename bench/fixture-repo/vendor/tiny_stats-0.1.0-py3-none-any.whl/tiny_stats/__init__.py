"""Tiny pure-Python statistics helpers (offline vendor fixture)."""

from __future__ import annotations

from typing import Iterable


def mean(values: Iterable[float]) -> float:
    data = list(values)
    if not data:
        raise ValueError("mean() requires at least one value")
    return sum(data) / len(data)


def stdev(values: Iterable[float]) -> float:
    data = list(values)
    if len(data) < 2:
        raise ValueError("stdev() requires at least two values")
    mu = mean(data)
    return (sum((value - mu) ** 2 for value in data) / (len(data) - 1)) ** 0.5
